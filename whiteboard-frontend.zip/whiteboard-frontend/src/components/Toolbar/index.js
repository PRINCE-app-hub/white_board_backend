import React, { useContext, useState } from "react";
import classes from "./index.module.css";
import cx from "classnames";
import { sendImageToEmail } from "../../utils/sendEmail"; 

import {
  FaSlash,
  FaRegCircle,
  FaArrowRight,
  FaPaintBrush,
  FaEraser,
  FaUndoAlt,
  FaRedoAlt,
  FaFont,
  FaDownload,
  FaEnvelope,
} from "react-icons/fa";
import { LuRectangleHorizontal } from "react-icons/lu";
import { TOOL_ITEMS } from "../../constants";
import boardContext from "../../store/board-context";

const Toolbar = () => {
  const { activeToolItem, changeToolHandler, undo, redo } =
    useContext(boardContext);

  const [email, setEmail] = useState("");
  const [showModal, setShowModal] = useState(false);

  const handleDownloadClick = () => {
    const canvas = document.getElementById("canvas");
    const data = canvas.toDataURL("image/png");
    const anchor = document.createElement("a");
    anchor.href = data;
    anchor.download = "board.png";
    anchor.click();
  };

  // ✅ This function is added inside the Toolbar component
  const handleSendEmail = async () => {
    const canvas = document.getElementById("canvas");
    if (!canvas) {
      alert("No canvas found.");
      return;
    }

    const imageBase64 = canvas.toDataURL("image/png");

    if (!email) {
      alert("Please enter a recipient email.");
      return;
    }

    await sendImageToEmail(imageBase64, email);
    setShowModal(false);
  };

  return (
    <div className={classes.container}>
      {/* Drawing Tools */}
      <div
        className={cx(classes.toolItem, {
          [classes.active]: activeToolItem === TOOL_ITEMS.BRUSH,
        })}
        onClick={() => changeToolHandler(TOOL_ITEMS.BRUSH)}
      >
        <FaPaintBrush />
      </div>
      <div
        className={cx(classes.toolItem, {
          [classes.active]: activeToolItem === TOOL_ITEMS.LINE,
        })}
        onClick={() => changeToolHandler(TOOL_ITEMS.LINE)}
      >
        <FaSlash />
      </div>
      <div
        className={cx(classes.toolItem, {
          [classes.active]: activeToolItem === TOOL_ITEMS.RECTANGLE,
        })}
        onClick={() => changeToolHandler(TOOL_ITEMS.RECTANGLE)}
      >
        <LuRectangleHorizontal />
      </div>
      <div
        className={cx(classes.toolItem, {
          [classes.active]: activeToolItem === TOOL_ITEMS.CIRCLE,
        })}
        onClick={() => changeToolHandler(TOOL_ITEMS.CIRCLE)}
      >
        <FaRegCircle />
      </div>
      <div
        className={cx(classes.toolItem, {
          [classes.active]: activeToolItem === TOOL_ITEMS.ARROW,
        })}
        onClick={() => changeToolHandler(TOOL_ITEMS.ARROW)}
      >
        <FaArrowRight />
      </div>
      <div
        className={cx(classes.toolItem, {
          [classes.active]: activeToolItem === TOOL_ITEMS.ERASER,
        })}
        onClick={() => changeToolHandler(TOOL_ITEMS.ERASER)}
      >
        <FaEraser />
      </div>
      <div
        className={cx(classes.toolItem, {
          [classes.active]: activeToolItem === TOOL_ITEMS.TEXT,
        })}
        onClick={() => changeToolHandler(TOOL_ITEMS.TEXT)}
      >
        <FaFont />
      </div>

      {/* Undo/Redo */}
      <div className={classes.toolItem} onClick={undo}>
        <FaUndoAlt />
      </div>
      <div className={classes.toolItem} onClick={redo}>
        <FaRedoAlt />
      </div>

      {/* Download */}
      <div className={classes.toolItem} onClick={handleDownloadClick}>
        <FaDownload />
      </div>

      {/* Export to Email */}
      <div className={classes.toolItem} onClick={() => setShowModal(true)}>
        <FaEnvelope />
      </div>

      {/* Modal for Email Input */}
      {showModal && (
        <div className={classes.modal}>
          <div className={classes.modalContent}>
            <h3>Send to Email</h3>
            <input
              type="email"
              placeholder="Recipient email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={classes.input}
            />
            <button onClick={handleSendEmail}>Send</button>
            <button onClick={() => setShowModal(false)}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Toolbar;
