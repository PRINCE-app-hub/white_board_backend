import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from '../pages/Auth';
import Signup from '../pages/Auth';
import WhiteboardPage from '../pages/WhiteboardPage';
import ProtectedRoute from './ProtectedRoutes';

function AppRoutes() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* Protect the whiteboard route (requires login) */}
        <Route
          path="/whiteboard"
          element={
            <ProtectedRoute>
              <WhiteboardPage />
            </ProtectedRoute>
          }
        />
      </Routes>
    </Router>
  );
}

export default AppRoutes;
