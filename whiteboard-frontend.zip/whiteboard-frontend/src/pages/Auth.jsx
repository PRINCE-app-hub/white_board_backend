"use client"

import { useState } from "react"
import { useAuth } from '../store/AuthContext'; // fix this path
import { useNavigate } from "react-router-dom";

// Complete Authentication System in One File
export default function AuthApp() {
  // Password strength calculation utility
  const navigate = useNavigate();
  const calculatePasswordStrength = (password) => {
    if (!password) return { score: 0, feedback: [], strength: "Very Weak" }

    let score = 0
    const feedback = []

    // Length check
    if (password.length >= 8) {
      score += 1
    } else {
      feedback.push("Use at least 8 characters")
    }

    if (password.length >= 12) {
      score += 1
    }

    // Character variety checks
    if (/[a-z]/.test(password)) {
      score += 1
    } else {
      feedback.push("Add lowercase letters")
    }

    if (/[A-Z]/.test(password)) {
      score += 1
    } else {
      feedback.push("Add uppercase letters")
    }

    if (/[0-9]/.test(password)) {
      score += 1
    } else {
      feedback.push("Add numbers")
    }

    if (/[^a-zA-Z0-9]/.test(password)) {
      score += 1
    } else {
      feedback.push("Add special characters (!@#$%^&*)")
    }

    // Common patterns (reduce score)
    if (/(.)\1{2,}/.test(password)) {
      score -= 1
      feedback.push("Avoid repeated characters")
    }

    if (/123|abc|qwe|password|admin/i.test(password)) {
      score -= 1
      feedback.push("Avoid common patterns")
    }

    // Determine strength level
    let strength = "Very Weak"
    let color = "#ef4444"

    if (score >= 5) {
      strength = "Very Strong"
      color = "#22c55e"
    } else if (score >= 4) {
      strength = "Strong"
      color = "#84cc16"
    } else if (score >= 3) {
      strength = "Good"
      color = "#eab308"
    } else if (score >= 2) {
      strength = "Fair"
      color = "#f97316"
    } else if (score >= 1) {
      strength = "Weak"
      color = "#f87171"
    }

    return {
      score: Math.max(0, Math.min(5, score)),
      feedback: feedback.slice(0, 3),
      strength,
      color,
    }
  }

  // Enhanced Password Input Component
  const EnhancedPasswordInput = ({
    value,
    onChange,
    disabled = false,
    label = "Password",
    placeholder = "Enter password",
    id = "password",
  }) => {
    const [showPassword, setShowPassword] = useState(false)
    const { score, strength, color } = calculatePasswordStrength(value)

    const requirements = [
      { test: (pwd) => pwd.length >= 8, text: "At least 8 characters" },
      { test: (pwd) => /[a-z]/.test(pwd), text: "One lowercase letter" },
      { test: (pwd) => /[A-Z]/.test(pwd), text: "One uppercase letter" },
      { test: (pwd) => /[0-9]/.test(pwd), text: "One number" },
      { test: (pwd) => /[^a-zA-Z0-9]/.test(pwd), text: "One special character" },
    ]

    const strengthPercentage = (score / 5) * 100

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
        <label htmlFor={id} style={{ fontSize: "0.875rem", fontWeight: "500", color: "#374151" }}>
          {label}
        </label>
        <div style={{ position: "relative" }}>
          <input
            id={id}
            type={showPassword ? "text" : "password"}
            placeholder={placeholder}
            value={value}
            onChange={onChange}
            disabled={disabled}
            style={{
              width: "100%",
              padding: "0.75rem",
              paddingRight: "2.5rem",
              border: "1px solid #d1d5db",
              borderRadius: "6px",
              fontSize: "0.875rem",
              outline: "none",
              transition: "border-color 0.2s",
              backgroundColor: disabled ? "#f9fafb" : "white",
              color: disabled ? "#9ca3af" : "black",
            }}
            onFocus={(e) => {
              e.target.style.borderColor = "#2563eb"
              e.target.style.boxShadow = "0 0 0 3px rgba(37, 99, 235, 0.1)"
            }}
            onBlur={(e) => {
              e.target.style.borderColor = "#d1d5db"
              e.target.style.boxShadow = "none"
            }}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            disabled={disabled}
            style={{
              position: "absolute",
              right: "0.75rem",
              top: "50%",
              transform: "translateY(-50%)",
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "#6b7280",
              fontSize: "1rem",
              padding: "0",
              width: "20px",
              height: "20px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {showPassword ? "🙈" : "👁️"}
          </button>
        </div>

        {value && (
          <div>
            <div style={{ marginTop: "0.75rem" }}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: "0.5rem",
                }}
              >
                <span style={{ fontSize: "0.75rem", fontWeight: "500", color: "#374151" }}>Strength</span>
                <span style={{ fontSize: "0.75rem", fontWeight: "500", color }}>{strength}</span>
              </div>
              <div
                style={{ width: "100%", height: "8px", background: "#e5e7eb", borderRadius: "4px", overflow: "hidden" }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${strengthPercentage}%`,
                    backgroundColor: color,
                    transition: "all 0.3s ease",
                    borderRadius: "4px",
                  }}
                />
              </div>
            </div>

            <div style={{ marginTop: "0.75rem" }}>
              <p style={{ fontSize: "0.875rem", fontWeight: "500", color: "#374151", marginBottom: "0.5rem" }}>
                Requirements:
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
                {requirements.map((req, index) => {
                  const isMet = req.test(value)
                  return (
                    <div
                      key={index}
                      style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "0.875rem" }}
                    >
                      <span
                        style={{
                          width: "16px",
                          height: "16px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: "12px",
                          color: isMet ? "#059669" : "#9ca3af",
                        }}
                      >
                        {isMet ? "✓" : "✗"}
                      </span>
                      <span style={{ color: isMet ? "#059669" : "#9ca3af" }}>{req.text}</span>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }
  const [activeTab, setActiveTab] = useState("login")
  const [loginData, setLoginData] = useState({ email: "", password: "" })
  const [signupData, setSignupData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [showPasswords, setShowPasswords] = useState({
    login: false,
    confirm: false,
  })
  const [acceptTerms, setAcceptTerms] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [errors, setErrors] = useState({ login: "", signup: "" })

// const handleLogin = async () => {
//   setIsLoading(true);
//   setErrors({}); // clear previous errors

//   try {
//     const res = await fetch("/api/login", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       credentials: "include", // needed if using cookies
//       body: JSON.stringify(loginData),
//     });

//     const data = await res.json();

//     if (!res.ok) {
//       throw new Error(data?.message || "Login failed");
//     }

//     console.log("Login successful:", data);
//     alert("Login successful!");
//   } catch (err) {
//     setErrors((prev) => ({
//       ...prev,
//       login: err.message || "Login failed. Please check your credentials.",
//     }));
//   } finally {
//     setIsLoading(false);
//   }
// };
// change (e) and added e.preventDefault();
const handleLogin = async (e) => {
  e.preventDefault();
  setIsLoading(true);
  setErrors({});
 console.log("🔁 handleLogin called");
 console.log("Sending login data:", loginData);

  try {
    const res = await fetch("http://localhost:5000/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
      body: JSON.stringify(loginData),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data?.error || "Login failed");
    }

    console.log("Login successful:", data);

    // ✅ Set auth context
    login(data.user); // <-- THIS was missing!

    alert("Login successful!");
    navigate("/whiteboard");
  } catch (err) {
    setErrors((prev) => ({
      ...prev,
      login: err.message || "Login failed. Please check your credentials.",
    }));
  } finally {
    setIsLoading(false);
  }
};

const { login } = useAuth();
const handleSignup = async (e) => {
  e.preventDefault();
  setErrors((prev) => ({ ...prev, signup: "" }));
  setIsLoading(true);

  const { firstName, lastName, email, password, confirmPassword } = signupData;

  if (!firstName || !lastName || !email || !password || !confirmPassword) {
    setErrors((prev) => ({ ...prev, signup: "Please fill in all fields" }));
    setIsLoading(false);
    return;
  }

  if (!email.includes("@")) {
    setErrors((prev) => ({ ...prev, signup: "Please enter a valid email address" }));
    setIsLoading(false);
    return;
  }

  if (password.length < 8) {
    setErrors((prev) => ({ ...prev, signup: "Password must be at least 8 characters long" }));
    setIsLoading(false);
    return;
  }

  if (password !== confirmPassword) {
    setErrors((prev) => ({ ...prev, signup: "Passwords do not match" }));
    setIsLoading(false);
    return;
  }

  if (!acceptTerms) {
    setErrors((prev) => ({ ...prev, signup: "Please accept the terms and conditions" }));
    setIsLoading(false);
    return;
  }

  try {
    const response = await fetch("http://localhost:5000/api/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include", // important for cookie-based auth
      body: JSON.stringify({
        name: `${firstName} ${lastName}`,
        email,
        password,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data?.error || "Signup failed");
    }

    login({ name: `${firstName} ${lastName}`, email }); // Set auth context
    alert("Account created successfully!");
    login({ name: `${firstName} ${lastName}`, email });
    navigate("/whiteboard"); // or wherever your protected page is

  } catch (err) {
    setErrors((prev) => ({ ...prev, signup: err.message || "Signup failed. Please try again." }));
  } finally {
    setIsLoading(false);
  }
};
  const styles = {
    app: {
      minHeight: "100vh",
      background: "linear-gradient(135deg, #dbeafe 0%, #e0e7ff 100%)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "1rem",
      fontFamily:
        '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif',
    },
    card: {
      background: "white",
      borderRadius: "12px",
      boxShadow: "0 10px 25px rgba(0, 0, 0, 0.1)",
      width: "100%",
      maxWidth: "400px",
      overflow: "hidden",
    },
    header: {
      padding: "2rem 2rem 1rem",
      textAlign: "center",
    },
    logo: {
      width: "48px",
      height: "48px",
      background: "#2563eb",
      borderRadius: "8px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      margin: "0 auto 1rem",
      color: "white",
      fontSize: "24px",
    },
    title: {
      fontSize: "1.5rem",
      fontWeight: "700",
      color: "#1f2937",
      marginBottom: "0.5rem",
    },
    description: {
      color: "#6b7280",
      fontSize: "0.875rem",
    },
    content: {
      padding: "0 2rem 2rem",
    },
    tabs: {
      display: "flex",
      background: "#f3f4f6",
      borderRadius: "8px",
      padding: "4px",
      marginBottom: "1.5rem",
    },
    tabButton: {
      flex: 1,
      padding: "0.5rem 1rem",
      border: "none",
      background: "transparent",
      borderRadius: "6px",
      fontSize: "0.875rem",
      fontWeight: "500",
      cursor: "pointer",
      transition: "all 0.2s",
      color: "#6b7280",
    },
    tabButtonActive: {
      background: "white",
      color: "#1f2937",
      boxShadow: "0 1px 3px rgba(0, 0, 0, 0.1)",
    },
    form: {
      display: "flex",
      flexDirection: "column",
      gap: "1rem",
    },
    formGroup: {
      display: "flex",
      flexDirection: "column",
      gap: "0.5rem",
    },
    formRow: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "1rem",
    },
    label: {
      fontSize: "0.875rem",
      fontWeight: "500",
      color: "#374151",
    },
    input: {
      width: "100%",
      padding: "0.75rem",
      border: "1px solid #d1d5db",
      borderRadius: "6px",
      fontSize: "0.875rem",
      transition: "border-color 0.2s",
      outline: "none",
    },
    inputWrapper: {
      position: "relative",
    },
    passwordToggle: {
      position: "absolute",
      right: "0.75rem",
      top: "50%",
      transform: "translateY(-50%)",
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "#6b7280",
      fontSize: "1rem",
      padding: "0",
      width: "20px",
      height: "20px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
    button: {
      width: "100%",
      padding: "0.75rem",
      background: "#2563eb",
      color: "white",
      border: "none",
      borderRadius: "6px",
      fontSize: "0.875rem",
      fontWeight: "500",
      cursor: "pointer",
      transition: "background-color 0.2s",
    },
    buttonDisabled: {
      background: "#9ca3af",
      cursor: "not-allowed",
    },
    alert: {
      padding: "0.75rem",
      borderRadius: "6px",
      fontSize: "0.875rem",
      marginBottom: "1rem",
      background: "#fef2f2",
      color: "#dc2626",
      border: "1px solid #fecaca",
    },
    checkboxWrapper: {
      display: "flex",
      alignItems: "flex-start",
      gap: "0.5rem",
    },
    checkboxLabel: {
      fontSize: "0.875rem",
      color: "#374151",
      lineHeight: "1.4",
    },
    link: {
      color: "#2563eb",
      textDecoration: "none",
    },
    passwordMatch: {
      display: "flex",
      alignItems: "center",
      gap: "0.25rem",
      fontSize: "0.875rem",
      marginTop: "0.5rem",
    },
    matchIndicator: {
      width: "4px",
      height: "4px",
      borderRadius: "50%",
      flexShrink: 0,
    },
  }

  return (
    <div style={styles.app}>
      <div style={styles.card}>
        <div style={styles.header}>
          <div style={styles.logo}>🎨</div>
          <h1 style={styles.title}>Whiteboard</h1>
          <p style={styles.description}>Sign in to your account or create a new one</p>
        </div>

        <div style={styles.content}>
          <div style={styles.tabs}>
            <button
              style={{
                ...styles.tabButton,
                ...(activeTab === "login" ? styles.tabButtonActive : {}),
              }}
              onClick={() => setActiveTab("login")}
            >
              Sign In
            </button>
            <button
              style={{
                ...styles.tabButton,
                ...(activeTab === "signup" ? styles.tabButtonActive : {}),
              }}
              onClick={() => setActiveTab("signup")}
            >
              Sign Up
            </button>
          </div>

          {activeTab === "login" && (
            <form onSubmit={handleLogin} style={styles.form}>
              {errors.login && <div style={styles.alert}>{errors.login}</div>}

              <div style={styles.formGroup}>
                <label htmlFor="login-email" style={styles.label}>
                  Email
                </label>
                <input
                  id="login-email"
                  type="email"
                  placeholder="Enter your email"
                  value={loginData.email}
                  onChange={(e) => setLoginData((prev) => ({ ...prev, email: e.target.value }))}
                  disabled={isLoading}
                  style={{
                    ...styles.input,
                    backgroundColor: isLoading ? "#f9fafb" : "white",
                    color: isLoading ? "#9ca3af" : "black",
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = "#2563eb"
                    e.target.style.boxShadow = "0 0 0 3px rgba(37, 99, 235, 0.1)"
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = "#d1d5db"
                    e.target.style.boxShadow = "none"
                  }}
                  required
                />
              </div>

              <div style={styles.formGroup}>
                <label htmlFor="login-password" style={styles.label}>
                  Password
                </label>
                <div style={styles.inputWrapper}>
                  <input
                    id="login-password"
                    type={showPasswords.login ? "text" : "password"}
                    placeholder="Enter your password"
                    value={loginData.password}
                    onChange={(e) => setLoginData((prev) => ({ ...prev, password: e.target.value }))}
                    disabled={isLoading}
                    style={{
                      ...styles.input,
                      paddingRight: "2.5rem",
                      backgroundColor: isLoading ? "#f9fafb" : "white",
                      color: isLoading ? "#9ca3af" : "black",
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = "#2563eb"
                      e.target.style.boxShadow = "0 0 0 3px rgba(37, 99, 235, 0.1)"
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = "#d1d5db"
                      e.target.style.boxShadow = "none"
                    }}
                    required
                  />
                  <button
                    type="button"
                    style={styles.passwordToggle}
                    onClick={() => setShowPasswords((prev) => ({ ...prev, login: !prev.login }))}
                    disabled={isLoading}
                  >
                    {showPasswords.login ? "🙈" : "👁️"}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                style={{
                  ...styles.button,
                  ...(isLoading ? styles.buttonDisabled : {}),
                  ":hover": !isLoading ? { backgroundColor: "#1d4ed8" } : {},
                }}
                disabled={isLoading}
                onMouseEnter={(e) => {
                  if (!isLoading) e.target.style.backgroundColor = "#1d4ed8"
                }}
                onMouseLeave={(e) => {
                  if (!isLoading) e.target.style.backgroundColor = "#2563eb"
                }}
              >
                {isLoading ? "Signing in..." : "Sign in"}
              </button>
            </form>
          )}

          {activeTab === "signup" && (
            <form onSubmit={handleSignup} style={styles.form}>
              {errors.signup && <div style={styles.alert}>{errors.signup}</div>}

              <div style={styles.formRow}>
                <div style={styles.formGroup}>
                  <label htmlFor="firstName" style={styles.label}>
                    First name
                  </label>
                  <input
                    id="firstName"
                    placeholder="John"
                    value={signupData.firstName}
                    onChange={(e) => setSignupData((prev) => ({ ...prev, firstName: e.target.value }))}
                    disabled={isLoading}
                    style={{
                      ...styles.input,
                      backgroundColor: isLoading ? "#f9fafb" : "white",
                      color: isLoading ? "#9ca3af" : "black",
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = "#2563eb"
                      e.target.style.boxShadow = "0 0 0 3px rgba(37, 99, 235, 0.1)"
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = "#d1d5db"
                      e.target.style.boxShadow = "none"
                    }}
                    required
                  />
                </div>
                <div style={styles.formGroup}>
                  <label htmlFor="lastName" style={styles.label}>
                    Last name
                  </label>
                  <input
                    id="lastName"
                    placeholder="Doe"
                    value={signupData.lastName}
                    onChange={(e) => setSignupData((prev) => ({ ...prev, lastName: e.target.value }))}
                    disabled={isLoading}
                    style={{
                      ...styles.input,
                      backgroundColor: isLoading ? "#f9fafb" : "white",
                      color: isLoading ? "#9ca3af" : "black",
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = "#2563eb"
                      e.target.style.boxShadow = "0 0 0 3px rgba(37, 99, 235, 0.1)"
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = "#d1d5db"
                      e.target.style.boxShadow = "none"
                    }}
                    required
                  />
                </div>
              </div>

              <div style={styles.formGroup}>
                <label htmlFor="signup-email" style={styles.label}>
                  Email
                </label>
                <input
                  id="signup-email"
                  type="email"
                  placeholder="john.doe@example.com"
                  value={signupData.email}
                  onChange={(e) => setSignupData((prev) => ({ ...prev, email: e.target.value }))}
                  disabled={isLoading}
                  style={{
                    ...styles.input,
                    backgroundColor: isLoading ? "#f9fafb" : "white",
                    color: isLoading ? "#9ca3af" : "black",
                  }}
                  onFocus={(e) => {
                    e.target.style.borderColor = "#2563eb"
                    e.target.style.boxShadow = "0 0 0 3px rgba(37, 99, 235, 0.1)"
                  }}
                  onBlur={(e) => {
                    e.target.style.borderColor = "#d1d5db"
                    e.target.style.boxShadow = "none"
                  }}
                  required
                />
              </div>

              <EnhancedPasswordInput
                value={signupData.password}
                onChange={(e) => setSignupData((prev) => ({ ...prev, password: e.target.value }))}
                disabled={isLoading}
                label="Create Password"
                placeholder="Create a password"
                id="signup-password"
              />

              <div style={styles.formGroup}>
                <label htmlFor="confirm-password" style={styles.label}>
                  Confirm password
                </label>
                <div style={styles.inputWrapper}>
                  <input
                    id="confirm-password"
                    type={showPasswords.confirm ? "text" : "password"}
                    placeholder="Confirm your password"
                    value={signupData.confirmPassword}
                    onChange={(e) => setSignupData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                    disabled={isLoading}
                    style={{
                      ...styles.input,
                      paddingRight: "2.5rem",
                      backgroundColor: isLoading ? "#f9fafb" : "white",
                      color: isLoading ? "#9ca3af" : "black",
                    }}
                    onFocus={(e) => {
                      e.target.style.borderColor = "#2563eb"
                      e.target.style.boxShadow = "0 0 0 3px rgba(37, 99, 235, 0.1)"
                    }}
                    onBlur={(e) => {
                      e.target.style.borderColor = "#d1d5db"
                      e.target.style.boxShadow = "none"
                    }}
                    required
                  />
                  <button
                    type="button"
                    style={styles.passwordToggle}
                    onClick={() => setShowPasswords((prev) => ({ ...prev, confirm: !prev.confirm }))}
                    disabled={isLoading}
                  >
                    {showPasswords.confirm ? "🙈" : "👁️"}
                  </button>
                </div>
                {signupData.confirmPassword && signupData.password !== signupData.confirmPassword && (
                  <div style={{ ...styles.passwordMatch, color: "#dc2626" }}>
                    <span style={{ ...styles.matchIndicator, background: "#dc2626" }} />
                    Passwords do not match
                  </div>
                )}
                {signupData.confirmPassword &&
                  signupData.password === signupData.confirmPassword &&
                  signupData.password && (
                    <div style={{ ...styles.passwordMatch, color: "#059669" }}>
                      <span style={{ ...styles.matchIndicator, background: "#059669" }} />
                      Passwords match
                    </div>
                  )}
              </div>

              <div style={styles.checkboxWrapper}>
                <input
                  type="checkbox"
                  id="terms"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  disabled={isLoading}
                  style={{ marginTop: "2px" }}
                />
                <label htmlFor="terms" style={styles.checkboxLabel}>
                  I agree to the{" "}
                  <a href="#" style={styles.link}>
                    Terms of Service
                  </a>{" "}
                  and{" "}
                  <a href="#" style={styles.link}>
                    Privacy Policy
                  </a>
                </label>
              </div>

              <button
                type="submit"
                style={{
                  ...styles.button,
                  ...(isLoading ? styles.buttonDisabled : {}),
                }}
                disabled={isLoading}
                onMouseEnter={(e) => {
                  if (!isLoading) e.target.style.backgroundColor = "#1d4ed8"
                }}
                onMouseLeave={(e) => {
                  if (!isLoading) e.target.style.backgroundColor = "#2563eb"
                }}
              >
                {isLoading ? "Creating account..." : "Create account"}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
