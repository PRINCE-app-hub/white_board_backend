import React from "react";
import Board from "../components/Board";
import Toolbar from "../components/Toolbar";
import Toolbox from "../components/Toolbox";
import BoardProvider from "../store/BoardProvider";
import ToolboxProvider from "../store/ToolboxProvider";

const WhiteboardPage = () => {
  return (
    <ToolboxProvider>
      <BoardProvider>
        <div style={{ display: "flex", flexDirection: "column", height: "100vh" }}>
          <Toolbar /> {/* Top bar */}
          
          <div style={{ display: "flex", flex: 1 }}>
            <Toolbox /> {/* Side panel */}
            <Board />   {/* Main canvas */}
          </div>
        </div>
      </BoardProvider>
    </ToolboxProvider>
  );
};

export default WhiteboardPage;
