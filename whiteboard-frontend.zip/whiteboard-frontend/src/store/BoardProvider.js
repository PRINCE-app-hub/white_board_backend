// import React, { useCallback, useReducer, useState } from "react";
// import boardContext from "./board-context";
// import { BOARD_ACTIONS, TOOL_ACTION_TYPES, TOOL_ITEMS } from "../constants";
// import { socket } from "../utils/socket";
// import {
//   createElement,
//   getSvgPathFromStroke,
//   isPointNearElement,
// } from "../utils/element";
// import getStroke from "perfect-freehand";

// const boardReducer = (state, action) => {
//   switch (action.type) {
//     case BOARD_ACTIONS.SET_ELEMENTS:
//       return {
//         ...state,
//         elements: action.payload.elements,
//         history: [action.payload.elements],
//         index: 0,
//       };

//     case BOARD_ACTIONS.CHANGE_TOOL:
//       return { ...state, activeToolItem: action.payload.tool };

//     case BOARD_ACTIONS.CHANGE_ACTION_TYPE:
//       return { ...state, toolActionType: action.payload.actionType };

//     case BOARD_ACTIONS.DRAW_DOWN: {
//       const { clientX, clientY, stroke, fill, size } = action.payload;
//       const newElement = createElement(
//         state.elements.length,
//         clientX,
//         clientY,
//         clientX,
//         clientY,
//         { type: state.activeToolItem, stroke, fill, size }
//       );
//       return {
//         ...state,
//         toolActionType:
//           state.activeToolItem === TOOL_ITEMS.TEXT
//             ? TOOL_ACTION_TYPES.WRITING
//             : TOOL_ACTION_TYPES.DRAWING,
//         elements: [...state.elements, newElement],
//       };
//     }

//     case BOARD_ACTIONS.DRAW_REMOTE: {
//       const newElements = [...state.elements, action.payload];
//       const newHistory = state.history.slice(0, state.index + 1);
//       newHistory.push(newElements);
//       return {
//         ...state,
//         elements: newElements,
//         history: newHistory,
//         index: state.index + 1,
//       };
//     }

//     case BOARD_ACTIONS.DRAW_MOVE: {
//       const { clientX, clientY } = action.payload;
//       const newElements = [...state.elements];
//       const index = newElements.length - 1;
//       const element = newElements[index];
//       if (!element) return state;

//       switch (element.type) {
//         case TOOL_ITEMS.LINE:
//         case TOOL_ITEMS.RECTANGLE:
//         case TOOL_ITEMS.CIRCLE:
//         case TOOL_ITEMS.ARROW: {
//           const { x1, y1, stroke, fill, size } = element;
//           const updated = createElement(index, x1, y1, clientX, clientY, {
//             type: element.type,
//             stroke,
//             fill,
//             size,
//           });
//           newElements[index] = updated;
//           break;
//         }
//         case TOOL_ITEMS.BRUSH: {
//           newElements[index].points.push({ x: clientX, y: clientY });
//           newElements[index].path = new Path2D(
//             getSvgPathFromStroke(getStroke(newElements[index].points))
//           );
//           break;
//         }
//         default:
//           return state;
//       }

//       return { ...state, elements: newElements };
//     }

//     case BOARD_ACTIONS.DRAW_UP: {
//       const newHistory = state.history.slice(0, state.index + 1);
//       newHistory.push([...state.elements]);
//       return { ...state, history: newHistory, index: state.index + 1 };
//     }

//     case BOARD_ACTIONS.ERASE: {
//       const { clientX, clientY } = action.payload;
//       const newElements = state.elements.filter(
//         (el) => !isPointNearElement(el, clientX, clientY)
//       );
//       const newHistory = state.history.slice(0, state.index + 1);
//       newHistory.push(newElements);
//       return {
//         ...state,
//         elements: newElements,
//         history: newHistory,
//         index: state.index + 1,
//       };
//     }

//     case BOARD_ACTIONS.CHANGE_TEXT: {
//       const newElements = [...state.elements];
//       const index = newElements.length - 1;
//       newElements[index].text = action.payload.text;
//       const newHistory = state.history.slice(0, state.index + 1);
//       newHistory.push(newElements);
//       return {
//         ...state,
//         toolActionType: TOOL_ACTION_TYPES.NONE,
//         elements: newElements,
//         history: newHistory,
//         index: state.index + 1,
//       };
//     }

//     case BOARD_ACTIONS.UNDO:
//       if (state.index <= 0) return state;
//       return {
//         ...state,
//         elements: state.history[state.index - 1],
//         index: state.index - 1,
//       };

//     case BOARD_ACTIONS.REDO:
//       if (state.index >= state.history.length - 1) return state;
//       return {
//         ...state,
//         elements: state.history[state.index + 1],
//         index: state.index + 1,
//       };

//     default:
//       return state;
//   }
// };

// const initialBoardState = {
//   activeToolItem: TOOL_ITEMS.BRUSH,
//   toolActionType: TOOL_ACTION_TYPES.NONE,
//   elements: [],
//   history: [[]],
//   index: 0,
// };

// const BoardProvider = ({ children }) => {
//   const [boardState, dispatchBoardAction] = useReducer(
//     boardReducer,
//     initialBoardState
//   );
//   const [canvases, setCanvases] = useState([]);
//   const [showList, setShowList] = useState(false);

//   const changeToolHandler = (tool) => {
//     dispatchBoardAction({
//       type: BOARD_ACTIONS.CHANGE_TOOL,
//       payload: { tool },
//     });
//   };

//   const boardMouseDownHandler = (event, toolboxState) => {
//     if (boardState.toolActionType === TOOL_ACTION_TYPES.WRITING) return;
//     const { clientX, clientY } = event;
//     if (boardState.activeToolItem === TOOL_ITEMS.ERASER) {
//       dispatchBoardAction({
//         type: BOARD_ACTIONS.CHANGE_ACTION_TYPE,
//         payload: { actionType: TOOL_ACTION_TYPES.ERASING },
//       });
//       return;
//     }
//     dispatchBoardAction({
//       type: BOARD_ACTIONS.DRAW_DOWN,
//       payload: {
//         clientX,
//         clientY,
//         stroke: toolboxState[boardState.activeToolItem]?.stroke,
//         fill: toolboxState[boardState.activeToolItem]?.fill,
//         size: toolboxState[boardState.activeToolItem]?.size,
//       },
//     });
//   };

//   const boardMouseMoveHandler = (event) => {
//     if (boardState.toolActionType === TOOL_ACTION_TYPES.WRITING) return;
//     const { clientX, clientY } = event;

//     if (boardState.toolActionType === TOOL_ACTION_TYPES.DRAWING) {
//       dispatchBoardAction({
//         type: BOARD_ACTIONS.DRAW_MOVE,
//         payload: { clientX, clientY },
//       });
//     } else if (boardState.toolActionType === TOOL_ACTION_TYPES.ERASING) {
//       dispatchBoardAction({
//         type: BOARD_ACTIONS.ERASE,
//         payload: { clientX, clientY },
//       });
//     }
//   };

//   const boardMouseUpHandler = () => {
//     if (boardState.toolActionType === TOOL_ACTION_TYPES.WRITING) return;

//     if (boardState.toolActionType === TOOL_ACTION_TYPES.DRAWING) {
//       dispatchBoardAction({ type: BOARD_ACTIONS.DRAW_UP });
//       const lastElement = boardState.elements[boardState.elements.length - 1];
//       socket.emit("draw-element", lastElement);
//     }

//     dispatchBoardAction({
//       type: BOARD_ACTIONS.CHANGE_ACTION_TYPE,
//       payload: { actionType: TOOL_ACTION_TYPES.NONE },
//     });
//   };

//   const textAreaBlurHandler = (text) => {
//     dispatchBoardAction({
//       type: BOARD_ACTIONS.CHANGE_TEXT,
//       payload: { text },
//     });
//   };

//   const boardUndoHandler = useCallback(() => {
//     dispatchBoardAction({ type: BOARD_ACTIONS.UNDO });
//   }, []);

//   const boardRedoHandler = useCallback(() => {
//     dispatchBoardAction({ type: BOARD_ACTIONS.REDO });
//   }, []);

//   const loadElements = (elements) => {
//     dispatchBoardAction({
//       type: BOARD_ACTIONS.SET_ELEMENTS,
//       payload: { elements },
//     });
//   };

//   const handleSaveCanvas = async () => {
//     try {
//       const res = await fetch("http://localhost:5000/api/canvas", {
//         method: "POST",
//         credentials: "include",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           elements: boardState.elements,
//           shared: [],
//         }),
//       });
//       const data = await res.json();
//       if (res.ok) {
//         alert("Canvas saved successfully!");
//       } else {
//         alert(`Failed to save canvas: ${data.message}`);
//       }
//     } catch (err) {
//       alert("Error saving canvas.");
//       console.error(err);
//     }
//   };

//   const fetchCanvases = async () => {
//     try {
//       const res = await fetch("http://localhost:5000/api/canvas", {
//         method: "GET",
//         credentials: "include",
//       });
//       const data = await res.json();
//       if (res.ok) {
//         setCanvases(data);
//         setShowList(true);
//       } else {
//         alert("Failed to fetch canvases.");
//       }
//     } catch (err) {
//       console.error("Fetch error:", err);
//       alert("Error fetching canvases.");
//     }
//   };

// const handleLoadCanvas = (savedElements) => {
//   const reconstructed = savedElements.map((el, idx) => {
//     if (el.type === TOOL_ITEMS.BRUSH) {
//       return {
//         ...el,
//         path: new Path2D(getSvgPathFromStroke(getStroke(el.points))),
//       };
//     } else if (
//       [TOOL_ITEMS.LINE, TOOL_ITEMS.RECTANGLE, TOOL_ITEMS.CIRCLE, TOOL_ITEMS.ARROW].includes(el.type)
//     ) {
//       return createElement(
//         idx,
//         el.x1,
//         el.y1,
//         el.x2,
//         el.y2,
//         {
//           type: el.type,
//           stroke: el.stroke,
//           fill: el.fill,
//           size: el.size,
//         }
//       );
//     } else if (el.type === TOOL_ITEMS.TEXT) {
//       return {
//         ...el,
//         text: el.text || "",
//       };
//     }
//     return el;
//   });

//   dispatchBoardAction({
//     type: BOARD_ACTIONS.SET_ELEMENTS,
//     payload: { elements: reconstructed },
//   });

//   setShowList(false);
// };


//   const boardContextValue = {
//     activeToolItem: boardState.activeToolItem,
//     elements: boardState.elements,
//     toolActionType: boardState.toolActionType,
//     changeToolHandler,
//     boardMouseDownHandler,
//     boardMouseMoveHandler,
//     boardMouseUpHandler,
//     textAreaBlurHandler,
//     undo: boardUndoHandler,
//     redo: boardRedoHandler,
//     loadElements,
//   };

//   return (
//     <boardContext.Provider value={boardContextValue}>
//       {children}

//       {/* Save Button */}
//       <button
//         style={{
//           position: "fixed",
//           top: "10px",
//           right: "10px",
//           zIndex: 1000,
//           padding: "8px 16px",
//           background: "#007bff",
//           color: "#fff",
//           border: "none",
//           borderRadius: "4px",
//         }}
//         onClick={handleSaveCanvas}
//       >
//         Save Canvas
//       </button>

//       {/* Get Canvas Button */}
//       <button
//         style={{
//           position: "fixed",
//           top: "50px",
//           right: "10px",
//           zIndex: 1000,
//           padding: "8px 16px",
//           background: "#28a745",
//           color: "#fff",
//           border: "none",
//           borderRadius: "4px",
//         }}
//         onClick={fetchCanvases}
//       >
//         Get Canvas
//       </button>

//       {/* Canvas List Popup */}
//       {showList && (
//         <div
//           style={{
//             position: "fixed",
//             top: "90px",
//             right: "10px",
//             zIndex: 1000,
//             background: "#fff",
//             border: "1px solid #ccc",
//             padding: "10px",
//             borderRadius: "6px",
//             maxHeight: "300px",
//             overflowY: "auto",
//             width: "250px",
//           }}
//         >
//           <h4>Available Canvases</h4>
//           {canvases.map((c) => (
//             <div key={c._id} style={{ marginBottom: "8px" }}>
//               <button
//                 onClick={() => handleLoadCanvas(c.elements)}
//                 style={{
//                   width: "100%",
//                   padding: "6px",
//                   background: "#f0f0f0",
//                   border: "1px solid #aaa",
//                   borderRadius: "4px",
//                   cursor: "pointer",
//                   textAlign: "left",
//                 }}
//               >
//                 Canvas: {new Date(c.createdAt).toLocaleString()}
//               </button>
//             </div>
//           ))}
//         </div>
//       )}
//     </boardContext.Provider>
//   );
// };

// export default BoardProvider;
import React, { useCallback, useReducer, useState } from "react";
import boardContext from "./board-context";
import { BOARD_ACTIONS, TOOL_ACTION_TYPES, TOOL_ITEMS } from "../constants";
import { socket } from "../utils/socket";
import { generateThumbnail } from "../utils/genrateThumbnail";
import {
  createElement,
  getSvgPathFromStroke,
  isPointNearElement,
} from "../utils/element";
import getStroke from "perfect-freehand";

const boardReducer = (state, action) => {
  switch (action.type) {
    case BOARD_ACTIONS.SET_ELEMENTS:
      return {
        ...state,
        elements: action.payload.elements,
        history: [action.payload.elements],
        index: 0,
      };

    case BOARD_ACTIONS.CHANGE_TOOL:
      return { ...state, activeToolItem: action.payload.tool };

    case BOARD_ACTIONS.CHANGE_ACTION_TYPE:
      return { ...state, toolActionType: action.payload.actionType };

    case BOARD_ACTIONS.DRAW_DOWN: {
      const { clientX, clientY, stroke, fill, size } = action.payload;
      const newElement = createElement(
        state.elements.length,
        clientX,
        clientY,
        clientX,
        clientY,
        { type: state.activeToolItem, stroke, fill, size }
      );
      return {
        ...state,
        toolActionType:
          state.activeToolItem === TOOL_ITEMS.TEXT
            ? TOOL_ACTION_TYPES.WRITING
            : TOOL_ACTION_TYPES.DRAWING,
        elements: [...state.elements, newElement],
      };
    }

    case BOARD_ACTIONS.DRAW_REMOTE: {
      const newElements = [...state.elements, action.payload];
      const newHistory = state.history.slice(0, state.index + 1);
      newHistory.push(newElements);
      return {
        ...state,
        elements: newElements,
        history: newHistory,
        index: state.index + 1,
      };
    }

    case BOARD_ACTIONS.DRAW_MOVE: {
      const { clientX, clientY } = action.payload;
      const newElements = [...state.elements];
      const index = newElements.length - 1;
      const element = newElements[index];
      if (!element) return state;

      switch (element.type) {
        case TOOL_ITEMS.LINE:
        case TOOL_ITEMS.RECTANGLE:
        case TOOL_ITEMS.CIRCLE:
        case TOOL_ITEMS.ARROW: {
          const { x1, y1, stroke, fill, size } = element;
          const updated = createElement(index, x1, y1, clientX, clientY, {
            type: element.type,
            stroke,
            fill,
            size,
          });
          newElements[index] = updated;
          break;
        }
        case TOOL_ITEMS.BRUSH: {
          newElements[index].points.push({ x: clientX, y: clientY });
          newElements[index].path = new Path2D(
            getSvgPathFromStroke(getStroke(newElements[index].points))
          );
          break;
        }
        default:
          return state;
      }

      return { ...state, elements: newElements };
    }

    case BOARD_ACTIONS.DRAW_UP: {
      const newHistory = state.history.slice(0, state.index + 1);
      newHistory.push([...state.elements]);
      return { ...state, history: newHistory, index: state.index + 1 };
    }

    case BOARD_ACTIONS.ERASE: {
      const { clientX, clientY } = action.payload;
      const newElements = state.elements.filter(
        (el) => !isPointNearElement(el, clientX, clientY)
      );
      const newHistory = state.history.slice(0, state.index + 1);
      newHistory.push(newElements);
      return {
        ...state,
        elements: newElements,
        history: newHistory,
        index: state.index + 1,
      };
    }

    case BOARD_ACTIONS.CHANGE_TEXT: {
      const newElements = [...state.elements];
      const index = newElements.length - 1;
      newElements[index].text = action.payload.text;
      const newHistory = state.history.slice(0, state.index + 1);
      newHistory.push(newElements);
      return {
        ...state,
        toolActionType: TOOL_ACTION_TYPES.NONE,
        elements: newElements,
        history: newHistory,
        index: state.index + 1,
      };
    }

    case BOARD_ACTIONS.UNDO:
      if (state.index <= 0) return state;
      return {
        ...state,
        elements: state.history[state.index - 1],
        index: state.index - 1,
      };

    case BOARD_ACTIONS.REDO:
      if (state.index >= state.history.length - 1) return state;
      return {
        ...state,
        elements: state.history[state.index + 1],
        index: state.index + 1,
      };

    default:
      return state;
  }
};

const initialBoardState = {
  activeToolItem: TOOL_ITEMS.BRUSH,
  toolActionType: TOOL_ACTION_TYPES.NONE,
  elements: [],
  history: [[]],
  index: 0,
};

const BoardProvider = ({ children }) => {
  const [boardState, dispatchBoardAction] = useReducer(
    boardReducer,
    initialBoardState
  );
  const [canvases, setCanvases] = useState([]);
  const [showList, setShowList] = useState(false);

  const changeToolHandler = (tool) => {
    dispatchBoardAction({
      type: BOARD_ACTIONS.CHANGE_TOOL,
      payload: { tool },
    });
  };

  const boardMouseDownHandler = (event, toolboxState) => {
    if (boardState.toolActionType === TOOL_ACTION_TYPES.WRITING) return;
    const { clientX, clientY } = event;
    if (boardState.activeToolItem === TOOL_ITEMS.ERASER) {
      dispatchBoardAction({
        type: BOARD_ACTIONS.CHANGE_ACTION_TYPE,
        payload: { actionType: TOOL_ACTION_TYPES.ERASING },
      });
      return;
    }
    dispatchBoardAction({
      type: BOARD_ACTIONS.DRAW_DOWN,
      payload: {
        clientX,
        clientY,
        stroke: toolboxState[boardState.activeToolItem]?.stroke,
        fill: toolboxState[boardState.activeToolItem]?.fill,
        size: toolboxState[boardState.activeToolItem]?.size,
      },
    });
  };

  const boardMouseMoveHandler = (event) => {
    if (boardState.toolActionType === TOOL_ACTION_TYPES.WRITING) return;
    const { clientX, clientY } = event;

    if (boardState.toolActionType === TOOL_ACTION_TYPES.DRAWING) {
      dispatchBoardAction({
        type: BOARD_ACTIONS.DRAW_MOVE,
        payload: { clientX, clientY },
      });
    } else if (boardState.toolActionType === TOOL_ACTION_TYPES.ERASING) {
      dispatchBoardAction({
        type: BOARD_ACTIONS.ERASE,
        payload: { clientX, clientY },
      });
    }
  };

  const boardMouseUpHandler = () => {
    if (boardState.toolActionType === TOOL_ACTION_TYPES.WRITING) return;

    if (boardState.toolActionType === TOOL_ACTION_TYPES.DRAWING) {
      dispatchBoardAction({ type: BOARD_ACTIONS.DRAW_UP });
      const lastElement = boardState.elements[boardState.elements.length - 1];
      socket.emit("draw-element", lastElement);
    }

    dispatchBoardAction({
      type: BOARD_ACTIONS.CHANGE_ACTION_TYPE,
      payload: { actionType: TOOL_ACTION_TYPES.NONE },
    });
  };

  const textAreaBlurHandler = (text) => {
    dispatchBoardAction({
      type: BOARD_ACTIONS.CHANGE_TEXT,
      payload: { text },
    });
  };

  const boardUndoHandler = useCallback(() => {
    dispatchBoardAction({ type: BOARD_ACTIONS.UNDO });
  }, []);

  const boardRedoHandler = useCallback(() => {
    dispatchBoardAction({ type: BOARD_ACTIONS.REDO });
  }, []);

  const loadElements = (elements) => {
    dispatchBoardAction({
      type: BOARD_ACTIONS.SET_ELEMENTS,
      payload: { elements },
    });
  };

  const handleSaveCanvas = async () => {
  const thumbnail = generateThumbnail(boardState.elements);

  //  Remove roughEle before sending to backend
  const cleanedElements = boardState.elements.map(({ roughEle, ...rest }) => rest);

  try {
    const res = await fetch("http://localhost:5000/api/canvas", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        elements: cleanedElements,
        shared: [],
        thumbnail,
      }),
    });

    const data = await res.json();
    if (res.ok) {
      alert("Canvas saved successfully!");
    } else {
      alert(`Failed to save canvas: ${data.message}`);
    }
  } catch (err) {
    alert("Error saving canvas.");
    console.error(err);
  }
};

  const fetchCanvases = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/canvas", {
        method: "GET",
        credentials: "include",
        
      });
      const data = await res.json();
      if (res.ok) {
        setCanvases(data);
        setShowList(true);
      } else {
        alert("Failed to fetch canvases.");
      }
    } catch (err) {
      console.error("Fetch error:", err);
      alert("Error fetching canvases.");
    }
  };
const handleDeleteCanvas = async (id) => {
  if (!window.confirm("Are you sure you want to delete this canvas?")) return;

  try {
    const res = await fetch(`http://localhost:5000/api/canvas/${id}`, {
      method: "DELETE",
      credentials: "include",
    });

    const data = await res.json();
    if (res.ok) {
      alert("Canvas deleted successfully!");
      setCanvases((prev) => prev.filter((c) => c._id !== id));
    } else {
      alert(`Failed to delete canvas: ${data.message}`);
    }
  } catch (err) {
    alert("Error deleting canvas.");
    console.error(err);
  }
};

const handleLoadCanvas = (savedElements) => {
  const reconstructed = savedElements.map((el, idx) => {
    if (el.type === TOOL_ITEMS.BRUSH) {
      return {
        ...el,
        path: new Path2D(getSvgPathFromStroke(getStroke(el.points))),
      };
    } else if (
      [TOOL_ITEMS.LINE, TOOL_ITEMS.RECTANGLE, TOOL_ITEMS.CIRCLE, TOOL_ITEMS.ARROW].includes(el.type)
    ) {
      return createElement(
        idx,
        el.x1,
        el.y1,
        el.x2,
        el.y2,
        {
          type: el.type,
          stroke: el.stroke,
          fill: el.fill,
          size: el.size,
        }
      );
    } else if (el.type === TOOL_ITEMS.TEXT) {
      return {
        ...el,
        text: el.text || "",
      };
    }
    return el;
  });

  dispatchBoardAction({
    type: BOARD_ACTIONS.SET_ELEMENTS,
    payload: { elements: reconstructed },
  });

  setShowList(false);
};


  const boardContextValue = {
    activeToolItem: boardState.activeToolItem,
    elements: boardState.elements,
    toolActionType: boardState.toolActionType,
    changeToolHandler,
    boardMouseDownHandler,
    boardMouseMoveHandler,
    boardMouseUpHandler,
    textAreaBlurHandler,
    undo: boardUndoHandler,
    redo: boardRedoHandler,
    loadElements,
  };

//   return (
//   <boardContext.Provider value={boardContextValue}>
//     {children}

//     {/* Save Button */}
//     <button
//       style={{
//         position: "fixed",
//         top: "10px",
//         right: "10px",
//         zIndex: 1000,
//         padding: "8px 16px",
//         background: "#007bff",
//         color: "#fff",
//         border: "none",
//         borderRadius: "4px",
//       }}
//       onClick={handleSaveCanvas}
//     >
//       Save Canvas
//     </button>

//     {/* Get Canvas Button */}
//     <button
//       style={{
//         position: "fixed",
//         top: "50px",
//         right: "10px",
//         zIndex: 1000,
//         padding: "8px 16px",
//         background: "#28a745",
//         color: "#fff",
//         border: "none",
//         borderRadius: "4px",
//       }}
//       onClick={fetchCanvases}
//     >
//       Get Canvas
//     </button>

//     {/* Canvas List Popup */}
//     {showList && (
//       <div
//         style={{
//           position: "fixed",
//           top: "90px",
//           right: "10px",
//           zIndex: 1000,
//           background: "#fff",
//           border: "1px solid #ccc",
//           padding: "10px",
//           borderRadius: "6px",
//           maxHeight: "300px",
//           overflowY: "auto",
//           width: "250px",
//         }}
//       >
//         <h4>Available Canvases</h4>
//         {canvases.map((c) => (
//           <div key={c._id} style={{ marginBottom: "12px" }}>
//             <button
//               onClick={() => handleLoadCanvas(c.elements)}
//               style={{
//                 width: "100%",
//                 padding: "6px",
//                 background: "#f0f0f0",
//                 border: "1px solid #aaa",
//                 borderRadius: "4px",
//                 cursor: "pointer",
//                 textAlign: "left",
//               }}
//             >
//               Canvas: {new Date(c.createdAt).toLocaleString()}
//             </button>

//             {c.thumbnail && (
//               <img
//                 src={c.thumbnail}
//                 alt="Canvas thumbnail"
//                 style={{
//                   width: "100%",
//                   marginTop: "6px",
//                   borderRadius: "4px",
//                   boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
//                 }}
//               />
//             )}
//           </div>
//         ))}
//       </div>
//     )}
//   </boardContext.Provider>
// );
return (
  <boardContext.Provider value={boardContextValue}>
    {children}

    {/* Save Button */}
    <button
      style={{
        position: "fixed",
        top: "10px",
        right: "10px",
        zIndex: 1000,
        padding: "8px 16px",
        background: "#007bff",
        color: "#fff",
        border: "none",
        borderRadius: "4px",
      }}
      onClick={handleSaveCanvas}
    >
      Save Canvas
    </button>

    {/* Get Canvas Button */}
    <button
      style={{
        position: "fixed",
        top: "50px",
        right: "10px",
        zIndex: 1000,
        padding: "8px 16px",
        background: "#28a745",
        color: "#fff",
        border: "none",
        borderRadius: "4px",
      }}
      onClick={fetchCanvases}
    >
      Get Canvas
    </button>

    {/* Canvas List Popup */}
    {showList && (
      <div
        style={{
          position: "fixed",
          top: "90px",
          right: "10px",
          zIndex: 1000,
          background: "#fff",
          border: "1px solid #ccc",
          padding: "10px",
          borderRadius: "6px",
          maxHeight: "300px",
          overflowY: "auto",
          width: "250px",
        }}
      >
        <h4>Available Canvases</h4>
        {canvases.map((c) => (
          <div key={c._id} style={{ marginBottom: "12px" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <button
                onClick={() => handleLoadCanvas(c.elements)}
                style={{
                  flexGrow: 1,
                  padding: "6px",
                  background: "#f0f0f0",
                  border: "1px solid #aaa",
                  borderRadius: "4px",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                Canvas: {new Date(c.createdAt).toLocaleString()}
              </button>
              <button
                onClick={() => handleDeleteCanvas(c._id)}
                style={{
                  marginLeft: "6px",
                  background: "#dc3545",
                  color: "white",
                  border: "none",
                  borderRadius: "4px",
                  padding: "6px",
                  cursor: "pointer",
                }}
              >
                🗑️
              </button>
            </div>

            {c.thumbnail && (
              <img
                src={c.thumbnail}
                alt="Canvas thumbnail"
                style={{
                  width: "100%",
                  marginTop: "6px",
                  borderRadius: "4px",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                }}
              />
            )}
          </div>
        ))}
      </div>
    )}
  </boardContext.Provider>
);

}
export default BoardProvider;
