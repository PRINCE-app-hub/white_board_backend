import React, { createContext, useContext, useState, useEffect } from 'react';
import { socket } from "../utils/socket";
export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const login = (userData) => {
    setUser(userData);
  };

  const logout = () => {
    setUser(null);
  };
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/check-auth', {
          credentials: 'include',
        });

        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
           socket.connect()
          return () => {
          socket.disconnect();
    };
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Auth check failed baby :', error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
   
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );

};

export const useAuth = () => useContext(AuthContext);
