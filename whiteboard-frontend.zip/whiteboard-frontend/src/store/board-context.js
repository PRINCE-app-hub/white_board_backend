import React, { createContext, useState, useCallback } from "react";

const boardContext = createContext({
  activeToolItem: "",
  changeToolHandler: () => {},
  undo: () => {},
  redo: () => {},
  
});



export default boardContext;
