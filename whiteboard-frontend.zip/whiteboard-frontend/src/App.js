import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Auth from './pages/Auth';
import WhiteboardPage from './pages/WhiteboardPage';
import ProtectedRoute from './router/ProtectedRoutes'; // Make sure this is imported

function App() {
  return (
    <Routes>
      <Route path="/" element={<Auth />} />
      <Route
        path="/whiteboard"
        element={
          <ProtectedRoute>
            <WhiteboardPage />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

export default App;
