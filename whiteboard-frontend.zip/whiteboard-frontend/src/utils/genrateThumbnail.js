import rough from "roughjs/bin/rough";
import getStroke from "perfect-freehand";
import { getSvgPathFromStroke } from "./element";
import { ARROW_LENGTH, TOOL_ITEMS } from "../constants";
import { getArrowHeadsCoordinates } from "./math";

const generator = rough.generator();

export const generateThumbnail = (elements) => {
  const canvas = document.createElement("canvas");
  const width = 200;
  const height = 150;
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  const roughCanvas = rough.canvas(canvas);

  if (!elements.length) return canvas.toDataURL("image/png");

  // 1. Compute bounding box
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  elements.forEach((el) => {
    if (el.type === TOOL_ITEMS.BRUSH) {
      el.points.forEach(({ x, y }) => {
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
      });
    } else {
      minX = Math.min(minX, el.x1, el.x2);
      minY = Math.min(minY, el.y1, el.y2);
      maxX = Math.max(maxX, el.x1, el.x2);
      maxY = Math.max(maxY, el.y1, el.y2);
    }
  });

  const contentWidth = maxX - minX;
  const contentHeight = maxY - minY;
  const scaleX = width / contentWidth;
  const scaleY = height / contentHeight;
  const scale = Math.min(scaleX, scaleY) * 0.9; // 90% scale for padding
  const offsetX = (width - contentWidth * scale) / 2;
  const offsetY = (height - contentHeight * scale) / 2;

  const scalePoint = (x, y) => [
    (x - minX) * scale + offsetX,
    (y - minY) * scale + offsetY,
  ];

  // 2. Draw elements
  elements.forEach((el) => {
    const options = {
      stroke: el.stroke || "#000",
      strokeWidth: el.size || 2,
      fill: el.fill || undefined,
      fillStyle: "solid",
      seed: el.id + 1,
    };

    switch (el.type) {
      case TOOL_ITEMS.BRUSH: {
        const scaledPoints = el.points.map(({ x, y }) => {
          const [sx, sy] = scalePoint(x, y);
          return { x: sx, y: sy };
        });
        const path = new Path2D(getSvgPathFromStroke(getStroke(scaledPoints)));
        ctx.strokeStyle = el.stroke || "#000";
        ctx.lineWidth = el.size || 2;
        ctx.stroke(path);
        break;
      }

      case TOOL_ITEMS.LINE: {
        const [x1, y1] = scalePoint(el.x1, el.y1);
        const [x2, y2] = scalePoint(el.x2, el.y2);
        roughCanvas.draw(generator.line(x1, y1, x2, y2, options));
        break;
      }

      case TOOL_ITEMS.RECTANGLE: {
        const [x1, y1] = scalePoint(el.x1, el.y1);
        const [x2, y2] = scalePoint(el.x2, el.y2);
        roughCanvas.draw(generator.rectangle(x1, y1, x2 - x1, y2 - y1, options));
        break;
      }

      case TOOL_ITEMS.CIRCLE: {
        const [x1, y1] = scalePoint(el.x1, el.y1);
        const [x2, y2] = scalePoint(el.x2, el.y2);
        const cx = (x1 + x2) / 2;
        const cy = (y1 + y2) / 2;
        const w = Math.abs(x2 - x1);
        const h = Math.abs(y2 - y1);
        roughCanvas.draw(generator.ellipse(cx, cy, w, h, options));
        break;
      }

      case TOOL_ITEMS.ARROW: {
        const [x1, y1] = scalePoint(el.x1, el.y1);
        const [x2, y2] = scalePoint(el.x2, el.y2);
        const { x3, y3, x4, y4 } = getArrowHeadsCoordinates(
          x1,
          y1,
          x2,
          y2,
          ARROW_LENGTH * scale
        );
        const points = [
          [x1, y1],
          [x2, y2],
          [x3, y3],
          [x2, y2],
          [x4, y4],
        ];
        roughCanvas.draw(generator.linearPath(points, options));
        break;
      }

      case TOOL_ITEMS.TEXT: {
        const [x, y] = scalePoint(el.x1, el.y1);
        ctx.font = `${(el.size || 16) * scale}px sans-serif`;
        ctx.fillStyle = el.stroke || "#000";
        ctx.fillText(el.text || "", x, y);
        break;
      }

      default:
        console.warn("Unknown type in thumbnail:", el.type);
        break;
    }
  });

  return canvas.toDataURL("image/png");
};
