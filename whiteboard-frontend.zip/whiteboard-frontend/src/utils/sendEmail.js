export const sendImageToEmail = async (imageBase64, to) => {
  try {
    const response = await fetch("http://localhost:5000/api/send-email", {
      method: "POST",
      credentials: "include", 
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to, imageBase64 }),
    });

    if (!response.ok) {
      console.log("Sending imageBase64 size:", imageBase64.length);

      const data = await response.json();
      throw new Error(data.message || "Email send failed");
    }

    alert("Email sent successfully!");
    console.log("Sending imageBase64 size:", imageBase64.length);

  } catch (err) {
    console.log("Sending imageBase64 size:", imageBase64.length);

    console.error("Send email error:", err);

    alert("Error sending email.");
  }
};
// const handleSendEmail = async () => {
//   const canvas = document.querySelector("canvas");
//   if (!canvas) {
//     alert("No canvas found.");
//     return;
//   }

//   const imageBase64 = canvas.toDataURL("image/png");

//   const to = prompt("Enter recipient email:");
//   if (!to) return;

//   try {
//     const res = await fetch("http://localhost:5000/api/send-email", {
//       method: "POST",
//       credentials: "include", 
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify({ to, imageBase64 }),
//     });

//     const data = await res.json();

//     if (res.ok) {
//       alert("Email sent successfully!");
//       setShowModal(false); // close modal
//     } else {
//       alert(`Failed to send email: ${data.message}`);
//     }
//   } catch (err) {
//     console.error("Send email error:", err);
//     alert("Error sending email.");
//   }
// };